# Run log

Kept by the Scribe. What was tried, in what order, what failed, with the lab-clock time. One
line per event. Tags: phase, call, reject, refused, hand-edit, rules-change, tool-push,
language (the report said more than the reply supported), other.

| Time | Tag | What happened |
|---|---|---|
| | | |
