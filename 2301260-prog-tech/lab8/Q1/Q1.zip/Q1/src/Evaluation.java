public interface Evaluation {
    public double evaluate();

    public char grade(double score);
}
