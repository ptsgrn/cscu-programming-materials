# TOI results, TOI 10 to TOI 21

<!-- The report skeleton. The server reads this shape to build the crit page and refuses a
     submission that breaks it: keep every heading, every table header and every row label
     exactly as they are. Fill the cells. Add rows only in the undetermined bucket and in
     the last section. -->

## Question a: medals and cutoffs per year

The cutoff is the lowest score that still received that medal. A cell the tool could not
fill says `undetermined`, and the year appears in the undetermined bucket with the reason.
No row is removed.

| Year | Gold | Gold cutoff | Silver | Silver cutoff | Bronze | Bronze cutoff |
|---|---|---|---|---|---|---|
| TOI 10 | | | | | | |
| TOI 11 | | | | | | |
| TOI 12 | | | | | | |
| TOI 13 | | | | | | |
| TOI 14 | | | | | | |
| TOI 15 | | | | | | |
| TOI 16 | | | | | | |
| TOI 17 | | | | | | |
| TOI 18 | | | | | | |
| TOI 19 | | | | | | |
| TOI 20 | | | | | | |
| TOI 21 | | | | | | |

## Question b: medals per centre, TOI 10 to TOI 21

One row per centre, all twelve years added up. A centre that appears in a workbook under
another spelling or code is the same centre. A label the tool could not place goes in the
undetermined bucket, not in a new row.

| Centre | Gold | Silver | Bronze | Total |
|---|---|---|---|---|
| BUU — Burapha University (มหาวิทยาลัยบูรพา) | | | | |
| CMU — Chiang Mai University (มหาวิทยาลัยเชียงใหม่) | | | | |
| KKU — Khon Kaen University (มหาวิทยาลัยขอนแก่น) | | | | |
| KMITL — King Mongkut's Institute of Technology Ladkrabang (สถาบันเทคโนโลยีพระจอมเกล้าเจ้าคุณทหารลาดกระบัง) | | | | |
| KMUTNB — King Mongkut's University of Technology North Bangkok (มหาวิทยาลัยเทคโนโลยีพระจอมเกล้าพระนครเหนือ) | | | | |
| KMUTT — King Mongkut's University of Technology Thonburi (มหาวิทยาลัยเทคโนโลยีพระจอมเกล้าธนบุรี) | | | | |
| KU — Kasetsart University (มหาวิทยาลัยเกษตรศาสตร์) | | | | |
| MWIT — Mahidol Wittayanusorn School (โรงเรียนมหิดลวิทยานุสรณ์) | | | | |
| NU — Naresuan University (มหาวิทยาลัยนเรศวร) | | | | |
| PSU — Prince of Songkla University, Hat Yai (มหาวิทยาลัยสงขลานครินทร์ หาดใหญ่) | | | | |
| PSUPN — Prince of Songkla University, Pattani (มหาวิทยาลัยสงขลานครินทร์ วิทยาเขตปัตตานี) | | | | |
| SSW — Samsen Wittayalai School, all sub-centres (โรงเรียนสามเสนวิทยาลัย) | | | | |
| SU — Silpakorn University (มหาวิทยาลัยศิลปากร) | | | | |
| SUT — Suranaree University of Technology (มหาวิทยาลัยเทคโนโลยีสุรนารี) | | | | |
| TU — Thammasat University (มหาวิทยาลัยธรรมศาสตร์) | | | | |
| UBU — Ubon Ratchathani University (มหาวิทยาลัยอุบลราชธานี) | | | | |
| WU — Walailak University (มหาวิทยาลัยวลัยลักษณ์) | | | | |

## Question c: people who medalled in two or more years

Answer: 

One number. No names, no usernames, no list.

## Reserve question: the centre whose students most often medal in consecutive years

Only if questions a, b and c are complete and the team says so. Otherwise leave the answer
line empty.

Answer: 

## Undetermined

Anything the tool could not answer, with the reason. Undetermined is a complete answer.

| Year or question | What could not be answered | Why |
|---|---|---|
| | | |

## What this report does not claim

What the agent was told and did not verify. One line each.

- 
