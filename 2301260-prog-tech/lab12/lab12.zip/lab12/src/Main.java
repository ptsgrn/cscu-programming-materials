public class Main {
    public static void main(String[] args) {
        LinkedCollection linkedCollection = new LinkedCollection();
        linkedCollection.remove();
        System.out.println("------------------------------------------------");
        linkedCollection.add(20);
        System.out.println("------------------------------------------------");
        linkedCollection.add(30);
        System.out.println("------------------------------------------------");
        linkedCollection.add(15);
        System.out.println("------------------------------------------------");
        linkedCollection.add(25);
        System.out.println("------------------------------------------------");
        linkedCollection.add(40);
        System.out.println("------------------------------------------------");
        linkedCollection.add(30);
        System.out.println("------------------------------------------------");
        linkedCollection.remove();
    }
}