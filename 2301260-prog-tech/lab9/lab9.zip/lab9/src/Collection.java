public interface Collection {
    public void add(int data);

    public void remove(int data);

    public boolean contain(int data);

    public boolean isEmpty();

    public int size();
}
