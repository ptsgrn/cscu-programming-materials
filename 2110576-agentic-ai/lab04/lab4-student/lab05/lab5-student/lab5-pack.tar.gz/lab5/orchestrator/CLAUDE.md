# The agent's rules file

<!-- Scribe: you write this file, by hand, in your own editor. Claude Code reads it at the
     start of every turn. Under each heading, write sentences that constrain. A heading left
     empty means the agent decides. When you change this file, tell the Driver to have the
     agent re-read it. Keep the headings. -->

## What ./wall returns



## What the agent may assume about a reply, and what it may not



## What the agent must do when a reply does not fit



## What the report may say, and what it may not



## Changes to the tool

<!-- One line per change the Operator pushed: the time, what changed, what the agent must
     now do differently. -->

